MASTER: [![CircleCI](https://circleci.com/gh/pdrmdrs/docker-express-ci-cd-aws/tree/master.svg?style=svg)](https://circleci.com/gh/pdrmdrs/docker-express-ci-cd-aws/tree/master)

DEV: [![CircleCI](https://circleci.com/gh/pdrmdrs/docker-express-ci-cd-aws/tree/dev.svg?style=svg)](https://circleci.com/gh/pdrmdrs/docker-express-ci-cd-aws/tree/dev)

# docker-express-ci-cd-aws
Simple Node.JS (Express.JS) app with docker. Working with CI/CD on GitHub and deploying to AWS ElasticBeanstalk
